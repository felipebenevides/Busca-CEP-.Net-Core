﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Busca_CEP.Models
{
    [DataContract]
    public class CEP 
    {
        [DataMember]
        public string cep { get; set; }
        [DataMember]
        public string logradouro { get; set; }
        [DataMember]
        public string complemento { get; set; }
        [DataMember]
        public string localidade { get; set; }
        [DataMember]
        public string uf { get; set; }
        [DataMember]
        public string unidade { get; set; }
        [DataMember]
        public string ibge { get; set; }
        [DataMember]
        public string gia { get; set; }
    }
}
