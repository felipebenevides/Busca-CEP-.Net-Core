﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Busca_CEP.Models
{
    [DataContract]
    public class JSONList
    {
        [DataMember]
        public List<CEP> ListaCEP { get; set; }

    }
    //[JsonArray]
    //public class Jobs { public List<CEP> JSON; }

    //[JsonArray]
    //public class CEP { public List<CEP> JSON; }



}
