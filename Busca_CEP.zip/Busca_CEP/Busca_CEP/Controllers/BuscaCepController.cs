﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Busca_CEP.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Busca_CEP.Controllers
{
    [Route("api/[controller]/[action]")]
    public class BuscaCepController : Controller
    {
   
        public async Task<CEP> ObterCEP (string CEP)
        {
            CEP cep = null;
            string CepFormatado = "https://viacep.com.br/ws/" + CEP + "/json/";
            var httpClient = new HttpClient();


            HttpResponseMessage response = await httpClient.GetAsync(CepFormatado);

            if(response.IsSuccessStatusCode)
            {
                var stringResult = await response.Content.ReadAsStringAsync();
                cep = JsonConvert.DeserializeObject<CEP>(stringResult);
            }

            return cep;
        }
        public async Task<List<CEP>>BuscaPorRua(string Estado ,string Cidade, string Rua)
        {
            //JSONList cep = null;
            List<CEP> cep = null;
            string RuaFormatado = "https://viacep.com.br/ws/" + Estado + "/" + Cidade + "/" + Rua + "/json/";
            var httpClient = new HttpClient();
            HttpResponseMessage response = await httpClient.GetAsync(RuaFormatado);

            if (response.IsSuccessStatusCode)
            {
                var stringResult = await response.Content.ReadAsStringAsync();

                cep = JsonConvert.DeserializeObject<List<CEP>>(stringResult.ToString());

            }
            return cep;
        }

        public async Task<CEP> BuscaRua(string CEP)
        {
            CEP cep = null;
            string CepFormatado = "https://viacep.com.br/ws/" + CEP + "/json/";
            var httpClient = new HttpClient();

            HttpResponseMessage response = await httpClient.GetAsync(CepFormatado);

            if (response.IsSuccessStatusCode)
            {
                var stringResult = await response.Content.ReadAsStringAsync();
                cep = JsonConvert.DeserializeObject<CEP>(stringResult);
            }

            return cep;
        }
    }
}